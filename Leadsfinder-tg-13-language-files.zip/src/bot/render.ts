import type { LeadView } from "../leads/view.ts";
import type { DashboardStats } from "../leads/repository.ts";
import { FILTERS, SORTS } from "../leads/repository.ts";
import type { JobProgress, JobSummary } from "../jobs/run-search-job.ts";
import { formatRange } from "../config/pricing.ts";
import { settings } from "../config/env.ts";
import { type Language, t, filterLabel, sortLabel, opportunityLabel, crmLabel, scoreLabel, scoreEvidence, opportunityReason } from "./i18n.ts";

export const TELEGRAM_LIMIT = 4000;
export function truncate(text: string, max = TELEGRAM_LIMIT): string { return text.length <= max ? text : `${text.slice(0, max - 1)}…`; }

const stars = (v: LeadView, lang: Language) => v.rating !== null ? `⭐ ${v.rating} (${v.reviewCount ?? 0} ${t(lang, "reviews")})` : `⭐ ${t(lang, "noRating")}`;

function websiteLine(v: LeadView, lang: Language): string {
  switch (v.websiteStatus) {
    case "NONE": return t(lang, "websiteNone");
    case "SOCIAL_ONLY": return t(lang, "websiteSocial");
    case "UNVERIFIED": return t(lang, "websiteUnverified");
    default: return t(lang, "websiteYes");
  }
}

export function renderLeadCard(v: LeadView, lang: Language = "ru"): string {
  const lines = [`${v.emoji} ${v.score}/100`, "", v.name, ...(v.category ? [v.category] : []), ...(v.city ? [`📍 ${v.city}`] : []), stars(v, lang), websiteLine(v, lang)];
  if (v.problems.length > 0) lines.push("", t(lang, "problems"), ...v.problems.slice(0, 4).map((p) => `⚠️ ${scoreLabel(p.code, p.label, lang)}`));
  if (v.opportunities.length > 0) lines.push("", t(lang, "opportunities"), ...v.opportunities.slice(0, 3).map((o) => opportunityLabel(o.code, lang)));
  return truncate(lines.join("\n"));
}

export function renderLeadDetails(v: LeadView, lang: Language = "ru"): string {
  const money = v.offeredPrice !== null ? `${v.offeredPrice}` : null;
  const brief = lang === "de" ? v.salesBriefDe : v.salesBrief;
  const lines = [
    `${v.emoji} ${v.score}/100 — ${v.name}`,
    [v.category, v.city].filter(Boolean).join(" · "), "", stars(v, lang), websiteLine(v, lang),
    ...(v.websiteUrl ? [`   ${v.websiteUrl}`] : []), ...(v.phone ? [`📞 ${v.phone}`] : []), ...(v.email ? [`📧 ${v.email}`] : []), ...(v.instagramUrl ? [`📸 ${v.instagramUrl}`] : []),
    "", `📌 ${t(lang, "crm")}: ${crmLabel(v.crmStatus, lang)}${v.isFavorite ? " ⭐" : ""}${money ? ` · ${t(lang, "price")}: ${money}` : ""}`,
    ...(v.lastContactAt ? [`${t(lang, "lastContact")}: ${v.lastContactAt.toISOString().slice(0, 10)}`] : []), "", t(lang, "whyScore"),
    ...v.items.map((i) => `+${i.points} ${scoreLabel(i.code, i.label, lang)} — ${scoreEvidence(i.code, i.evidence, lang)}`),
  ];
  if (v.opportunities.length > 0) lines.push("", t(lang, "recommended"), ...v.opportunities.map((o) => `${opportunityLabel(o.code, lang)} — ${opportunityReason(o.code, o.reason, lang)}`));
  if (brief) lines.push("", `— ${t(lang, "salesBrief").toUpperCase()} —`, brief);
  if (v.notes.length > 0) lines.push("", t(lang, "notes") + ":", ...v.notes.slice(0, 3).map((n) => `• ${n.text}`));
  if (v.latestOutreach) lines.push("", t(lang, "latestMessage"));
  return truncate(lines.join("\n"));
}

export function renderListHeader(total: number, shown: number, view: "all" | "fav", filters: string[], sort: string, lang: Language = "ru"): string {
  const filterNames = FILTERS.filter((f) => filters.includes(f.code)).map((f) => filterLabel(f.code, lang));
  const sortName = sortLabel(sort, lang);
  return [view === "fav" ? `⭐ ${t(lang, "favorites")} (${shown})` : `📋 ${t(lang, "myLeads")} (${shown} ${lang === "de" ? "von" : "из"} ${total})`, `${t(lang, "filters")}: ${filterNames.length > 0 ? filterNames.join(", ") : t(lang, "noFilters")}`, `${t(lang, "sort")}: ${sortName}`, shown === 0 ? `\n${t(lang, "noLeads")}` : ""].filter(Boolean).join("\n");
}

export function renderProgress(p: JobProgress | { phase: "start" }, niche: string, location: string, lang: Language = "ru"): string {
  const head = `🔎 ${niche} · ${location}`;
  if (p.phase === "start" || p.phase === "search") return `${head}\n\n${t(lang, "finding")}`;
  if (p.phase === "analysis") {
    const c = p.counters;
    const lines = [head, "", t(lang, "findingDone"), `${t(lang, "found")}: ${p.found}`, "", `${t(lang, "analyzing")}: ${c.processed}/${c.total}`, `${t(lang, "withWebsite")}: ${c.withWebsite}`, `${t(lang, "withoutWebsite")}: ${c.withoutWebsite}`, `${t(lang, "potential")}: ${c.promising}`, `${t(lang, "analyzed")}: ${c.analyzed}`];
    if (c.errors > 0) lines.push(`${t(lang, "siteError")}: ${c.errors}`);
    if (c.failed > 0) lines.push(`${t(lang, "processingErrors")}: ${c.failed}`);
    return lines.join("\n");
  }
  if (p.phase === "scoring") return `${head}\n\n${t(lang, "scoring")}`;
  return `${head}\n\n${t(lang, "briefProgress")}: ${p.done}/${p.total}`;
}

export function renderSummary(s: JobSummary, lang: Language = "ru"): string {
  if (s.status === "FAILED") return `${t(lang, "searchError")}\n\n${s.error ?? t(lang, "unknownError")}\n\n${t(lang, "retry")} ${t(lang, "checkKeys")}`;
  const lines = [s.status === "DONE" ? `✅ ${lang === "de" ? "Analyse abgeschlossen" : "Анализ завершён"}` : `⚠️ ${lang === "de" ? "Analyse abgeschlossen (wegen Limit gestoppt)" : "Анализ завершён (остановлен по лимиту)"}`, "", `${s.found} ${t(lang, "found").toLowerCase()} ${lang === "de" ? "Unternehmen" : "компаний"}`, `${s.withWebsite} ${t(lang, "websites")}`, `${s.withoutWebsite} ${t(lang, "withoutWebsites")}`, `${s.promising} ${t(lang, "promising")}`, `${s.leadsCreated} ${t(lang, "leadsScored")}`, "", `🔥 ${s.hotLeads} ${t(lang, "hotLeads")} ${settings.hotScore()}+`];
  if (s.aiBriefs > 0) lines.push(`${t(lang, "aiBriefs")}: ${s.aiBriefs}`);
  if (s.limitsHit.length > 0) lines.push("", `${t(lang, "limitHit")}: ${s.limitsHit.join(", ")}`, t(lang, "partial"));
  if (s.costMax > 0) lines.push("", `${t(lang, "costEstimate")}: ${formatRange({ min: s.costMin, max: s.costMax })}`);
  return lines.join("\n");
}

export function renderDashboard(stats: DashboardStats, spend: { min: number; max: number }, budgetEur: number, runningJob: boolean, lang: Language = "ru"): string {
  const st = stats.byStatus;
  return [t(lang, "dashboard"), "", `${t(lang, "totalLeads")}: ${stats.total}`, `🔥 ${t(lang, "hot")} (${settings.hotScore()}+): ${stats.hot}`, `⭐ ${t(lang, "favoriteCount")}: ${stats.favorites}`, "", `${t(lang, "crmTitle")}:`, `${crmLabel("NEW", lang)} ${st.NEW ?? 0} · ${crmLabel("CONTACTED", lang)} ${st.CONTACTED ?? 0} · ${crmLabel("REPLIED", lang)} ${st.REPLIED ?? 0}`, `${crmLabel("NEGOTIATION", lang)} ${st.NEGOTIATION ?? 0} · ${crmLabel("CLIENT", lang)} ${st.CLIENT ?? 0}`, `${crmLabel("REFUSED", lang)} ${st.REFUSED ?? 0} · ${crmLabel("NOT_RELEVANT", lang)} ${st.NOT_RELEVANT ?? 0}`, "", `${t(lang, "apiSpend")}: ${formatRange(spend)} / €${budgetEur}`, ...(runningJob ? ["", t(lang, "currentSearch")] : [])].join("\n");
}
