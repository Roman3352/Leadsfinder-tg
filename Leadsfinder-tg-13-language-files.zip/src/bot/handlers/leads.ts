import type { BotContext } from "../session.ts";
import {
  filtersKeyboard,
  leadCardKeyboard,
  leadDetailsKeyboard,
  listKeyboard,
  messageKeyboard,
  PAGE_SIZE,
  sortKeyboard,
  statusKeyboard,
} from "../keyboards.ts";
import { renderLeadCard, renderLeadDetails, renderListHeader, truncate } from "../render.ts";
import { getServices } from "../services.ts";
import { answer, parsePrice, showOrEdit } from "../util.ts";
import {
  addNote,
  applyFilters,
  getUserSetting,
  loadLeadView,
  loadLeadViews,
  setCrmStatus,
  setOfferedPrice,
  sortViews,
  toggleFavorite,
} from "../../leads/repository.ts";
import { CRM_STATUSES, type CrmStatusName } from "../../leads/view.ts";
import { ensureSalesBrief, generateOutreach } from "../../leads/ai.ts";
import { BudgetExceededError } from "../../jobs/budget.ts";
import { t, crmLabel } from "../i18n.ts";

// ---------- список ----------

export async function showLeadList(ctx: BotContext, view: "all" | "fav", page = 0): Promise<void> {
  await answer(ctx);
  ctx.session.listView = view;
  const { db } = getServices();

  const all = await loadLeadViews(db);
  const base = view === "fav" ? all.filter((v) => v.isFavorite) : all;
  const filtered = sortViews(applyFilters(base, ctx.session.filters), ctx.session.sort);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(0, page), totalPages - 1);
  const slice = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  const text = renderListHeader(base.length, filtered.length, view, ctx.session.filters, ctx.session.sort, ctx.session.language);
  await showOrEdit(ctx, text, listKeyboard(slice, safePage, totalPages, ctx.session.language));
}

export async function showPage(ctx: BotContext, page: number): Promise<void> {
  await showLeadList(ctx, ctx.session.listView, page);
}

export async function showFilters(ctx: BotContext): Promise<void> {
  await answer(ctx);
  await showOrEdit(ctx, t(ctx.session.language, "filtersTitle"), filtersKeyboard(ctx.session.filters, ctx.session.language));
}

export async function toggleFilter(ctx: BotContext, code: string): Promise<void> {
  await answer(ctx);
  const set = new Set(ctx.session.filters);
  if (set.has(code)) set.delete(code);
  else set.add(code);
  ctx.session.filters = [...set];
  await showOrEdit(ctx, t(ctx.session.language, "filtersTitle"), filtersKeyboard(ctx.session.filters, ctx.session.language));
}

export async function clearFilters(ctx: BotContext): Promise<void> {
  ctx.session.filters = [];
  await showFilters(ctx);
}

export async function showSort(ctx: BotContext): Promise<void> {
  await answer(ctx);
  await showOrEdit(ctx, t(ctx.session.language, "sortTitle"), sortKeyboard(ctx.session.sort, ctx.session.language));
}

export async function setSort(ctx: BotContext, code: string): Promise<void> {
  ctx.session.sort = code;
  await showLeadList(ctx, ctx.session.listView, 0);
}

// ---------- лид ----------

async function requireView(ctx: BotContext, leadId: string) {
  const view = await loadLeadView(leadId, getServices().db);
  if (!view) {
    await answer(ctx, t(ctx.session.language, "leadNotFound"));
    await ctx.reply(t(ctx.session.language, "deletedLead"));
  }
  return view;
}

export async function openDetails(ctx: BotContext, leadId: string, asNewMessage = false): Promise<void> {
  await answer(ctx);
  const view = await requireView(ctx, leadId);
  if (!view) return;
  const text = renderLeadDetails(view, ctx.session.language);
  if (asNewMessage) await ctx.reply(text, { reply_markup: leadDetailsKeyboard(view, ctx.session.language) });
  else await showOrEdit(ctx, text, leadDetailsKeyboard(view, ctx.session.language));
}

export async function onToggleFavorite(ctx: BotContext, leadId: string): Promise<void> {
  const { db } = getServices();
  const next = await toggleFavorite(leadId, db);
  await answer(ctx, next ? t(ctx.session.language, "addedFavorite") : t(ctx.session.language, "removedFavorite"));
  const view = await loadLeadView(leadId, db);
  if (!view) return;
  const isDetails = /Почему такой score|Warum dieser Score/.test((ctx.callbackQuery?.message as any)?.text ?? "");
  if (isDetails) await showOrEdit(ctx, renderLeadDetails(view, ctx.session.language), leadDetailsKeyboard(view, ctx.session.language));
  else await showOrEdit(ctx, renderLeadCard(view, ctx.session.language), leadCardKeyboard(view, ctx.session.language));
}

export async function showStatusMenu(ctx: BotContext, leadId: string): Promise<void> {
  await answer(ctx);
  const view = await requireView(ctx, leadId);
  if (!view) return;
  await ctx.editMessageReplyMarkup({ reply_markup: statusKeyboard(leadId, view.crmStatus, ctx.session.language) }).catch(() => {});
}

export async function onSetStatus(ctx: BotContext, leadId: string, status: string): Promise<void> {
  if (!(CRM_STATUSES as readonly string[]).includes(status)) {
    await answer(ctx, t(ctx.session.language, "unknownStatus"));
    return;
  }
  const { db } = getServices();
  await setCrmStatus(leadId, status as CrmStatusName, db);
  await answer(ctx, `${t(ctx.session.language, "crm")}: ${crmLabel(status, ctx.session.language)}`);
  const view = await loadLeadView(leadId, db);
  if (view) await showOrEdit(ctx, renderLeadDetails(view, ctx.session.language), leadDetailsKeyboard(view, ctx.session.language));
}

export async function askNote(ctx: BotContext, leadId: string): Promise<void> {
  await answer(ctx);
  ctx.session.step = "awaiting_note";
  ctx.session.targetLeadId = leadId;
  await ctx.reply(t(ctx.session.language, "writeNote"));
}

export async function askPrice(ctx: BotContext, leadId: string): Promise<void> {
  await answer(ctx);
  ctx.session.step = "awaiting_price";
  ctx.session.targetLeadId = leadId;
  await ctx.reply(t(ctx.session.language, "writePrice"));
}

export async function onNoteText(ctx: BotContext, text: string): Promise<void> {
  const leadId = ctx.session.targetLeadId;
  ctx.session.step = "idle";
  if (!leadId) return;
  await addNote(leadId, text.trim(), getServices().db);
  await ctx.reply(t(ctx.session.language, "noteSaved"));
}

export async function onPriceText(ctx: BotContext, text: string): Promise<void> {
  const leadId = ctx.session.targetLeadId;
  const price = parsePrice(text);
  if (price === null) {
    await ctx.reply(t(ctx.session.language, "invalidPrice"));
    return;
  }
  ctx.session.step = "idle";
  if (!leadId) return;
  await setOfferedPrice(leadId, price === 0 ? null : price, getServices().db);
  await ctx.reply(price === 0 ? t(ctx.session.language, "priceReset") : `${t(ctx.session.language, "priceSaved")}: ${price}`);
}

// ---------- AI ----------

function aiUnavailable(ctx: BotContext): boolean {
  if (getServices().llm) return false;
  void ctx.reply(t(ctx.session.language, "aiUnavailable"));
  return true;
}

export async function onBrief(ctx: BotContext, leadId: string): Promise<void> {
  if (aiUnavailable(ctx)) {
    await answer(ctx);
    return;
  }
  await answer(ctx, t(ctx.session.language, "preparingBrief"));
  const services = getServices();
  try {
    await ensureSalesBrief({ db: services.db, llm: services.llm! }, leadId, ctx.session.language);
    const view = await loadLeadView(leadId, services.db);
    if (view) await showOrEdit(ctx, renderLeadDetails(view, ctx.session.language), leadDetailsKeyboard(view, ctx.session.language));
  } catch (err) {
    await reportAiError(ctx, err);
  }
}

export async function onMessage(ctx: BotContext, leadId: string, regenerate: boolean): Promise<void> {
  const services = getServices();
  const view = await requireView(ctx, leadId);
  if (!view) return;

  if (view.latestOutreach && !regenerate) {
    await answer(ctx);
    await ctx.reply(truncate(view.latestOutreach), { reply_markup: messageKeyboard(leadId, ctx.session.language) });
    return;
  }
  if (aiUnavailable(ctx)) {
    await answer(ctx);
    return;
  }

  await answer(ctx, t(ctx.session.language, "writingMessage"));
  const senderSetting = await getUserSetting(String(ctx.from!.id), "senderName", services.db);
  const senderName = typeof senderSetting === "string" && senderSetting ? senderSetting : "[Ihr Name]";
  try {
    const message = await generateOutreach({ db: services.db, llm: services.llm! }, leadId, senderName);
    await ctx.reply(truncate(message), { reply_markup: messageKeyboard(leadId, ctx.session.language) });
    if (senderName === "[Ihr Name]") {
      await ctx.reply(t(ctx.session.language, "signatureHint"));
    }
  } catch (err) {
    await reportAiError(ctx, err);
  }
}

async function reportAiError(ctx: BotContext, err: unknown): Promise<void> {
  if (err instanceof BudgetExceededError) {
    await ctx.reply(`${t(ctx.session.language, "budgetReached")}: ${err.reason}`);
    return;
  }
  console.error("[bot] AI error:", err instanceof Error ? err.message : err);
  await ctx.reply(`${t(ctx.session.language, "aiError")}: ${err instanceof Error ? err.message : (ctx.session.language === "de" ? "Fehler" : "ошибка")}. ${t(ctx.session.language, "tryLater")}`);
}
