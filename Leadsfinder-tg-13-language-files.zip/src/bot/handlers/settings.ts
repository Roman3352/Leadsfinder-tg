import type { BotContext } from "../session.ts";
import { languageKeyboard, mainMenuKeyboard, settingsKeyboard, COUNT_OPTIONS } from "../keyboards.ts";
import { renderDashboard, truncate } from "../render.ts";
import { getServices } from "../services.ts";
import { answer, showOrEdit } from "../util.ts";
import { computeDashboard, getOrCreateUser, getUserSetting, loadLeadViews, setUserSetting } from "../../leads/repository.ts";
import { getMonthlySpend } from "../../jobs/budget.ts";
import { settings } from "../../config/env.ts";
import { estimateSearchCost } from "../../cost/estimate.ts";
import { formatRange } from "../../config/pricing.ts";
import { type Language, t } from "../i18n.ts";

export async function showHome(ctx: BotContext): Promise<void> {
  await answer(ctx);
  ctx.session.step = "idle";
  const lang = ctx.session.language;
  await ctx.reply(`${t(lang, "homeTitle")}\n\n${t(lang, "chooseAction")}`, { reply_markup: mainMenuKeyboard(lang) });
}

export async function showDashboard(ctx: BotContext): Promise<void> {
  await answer(ctx);
  const { db } = getServices();
  const user = await getOrCreateUser(String(ctx.from!.id), db);
  const [views, spend, running] = await Promise.all([
    loadLeadViews(db),
    getMonthlySpend(db),
    db.searchJob.findFirst({ where: { userId: user.id, status: "RUNNING" } }),
  ]);
  await ctx.reply(renderDashboard(computeDashboard(views), spend, settings.maxMonthlyBudgetEur(), !!running, ctx.session.language), {
    reply_markup: mainMenuKeyboard(ctx.session.language),
  });
}

export async function showSettings(ctx: BotContext): Promise<void> {
  await answer(ctx);
  const lang = ctx.session.language;
  const services = getServices();
  const spend = await getMonthlySpend(services.db);
  const limits = settings.jobLimits();
  const sender = await getUserSetting(String(ctx.from!.id), "senderName", services.db);
  const mark = (ok: boolean) => (ok ? "✅" : "❌");
  const languageName = lang === "de" ? "Deutsch" : "Русский";

  const lines = [
    t(lang, "settingsTitle"),
    "",
    `${t(lang, "apiKeys")}: Google ${mark(!!services.keys.google)} · Firecrawl ${mark(!!services.keys.firecrawl)} · PageSpeed ${mark(!!services.keys.pagespeed)} · AI ${mark(!!services.llm)}${services.llm ? ` (${services.llm.model})` : ""}`,
    "",
    t(lang, "limits"),
    `Google ${limits.maxGoogleRequests} · Firecrawl ${limits.maxFirecrawlCredits} · PageSpeed ${limits.maxPagespeedRequests} · AI ${limits.maxAiCalls}`,
    `${t(lang, "monthlyBudget")}: €${settings.maxMonthlyBudgetEur()} · ${t(lang, "spent")}: ${formatRange(spend)}`,
    `${t(lang, "briefRule")} ${settings.aiMinScore()}; ${t(lang, "hotRule")} ${settings.hotScore()}+`,
    "",
    t(lang, "searchCost"),
    ...COUNT_OPTIONS.map((n) => `${n} ${lang === "de" ? "Unternehmen" : "компаний"} → ${formatRange(estimateSearchCost(n))}`),
    t(lang, "costNote"),
    "",
    `${t(lang, "signature")}: ${typeof sender === "string" && sender ? sender : t(lang, "notSet")}`,
    `${t(lang, "languageCurrent")}: ${languageName}`,
  ];
  await showOrEdit(ctx, truncate(lines.join("\n")), settingsKeyboard(lang));
}

export async function showLanguageMenu(ctx: BotContext): Promise<void> {
  await answer(ctx);
  await showOrEdit(ctx, t(ctx.session.language, "chooseLanguage"), languageKeyboard());
}

export async function setLanguage(ctx: BotContext, lang: Language): Promise<void> {
  await answer(ctx);
  ctx.session.language = lang;
  await setUserSetting(String(ctx.from!.id), "language", lang, getServices().db);
  await showOrEdit(ctx, t(lang, "languageChanged"), mainMenuKeyboard(lang));
}

export async function askSenderName(ctx: BotContext): Promise<void> {
  await answer(ctx);
  ctx.session.step = "awaiting_sender_name";
  await ctx.reply(ctx.session.language === "de" ? "✏️ Gib den Namen für die Nachrichtensignatur ein (z. B. Max Mustermann):" : "✏️ Напишите имя для подписи в сообщениях (например: Max Mustermann):");
}

export async function onSenderNameText(ctx: BotContext, text: string): Promise<void> {
  const lang = ctx.session.language;
  const name = text.trim().slice(0, 80);
  if (name.length < 2) {
    await ctx.reply(t(lang, "tooShort"));
    return;
  }
  ctx.session.step = "idle";
  await setUserSetting(String(ctx.from!.id), "senderName", name, getServices().db);
  await ctx.reply(`${t(lang, "saved")}: ${name}`);
}
