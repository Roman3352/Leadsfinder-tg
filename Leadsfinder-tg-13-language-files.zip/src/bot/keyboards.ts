import { InlineKeyboard } from "grammy";
import { CRM_STATUSES, type LeadView } from "../leads/view.ts";
import { FILTERS, SORTS } from "../leads/repository.ts";
import { type Language, t, nicheLabel, filterLabel, sortLabel, crmLabel } from "./i18n.ts";

export const NICHES = [
  "Fahrzeugaufbereitung",
  "Car Wrapping",
  "PPF",
  "Keramikversiegelung",
  "Autowerkstatt",
  "Autohaus",
  "Friseur",
  "Barber",
  "Beauty",
  "Fitnessstudio",
  "Handwerker",
  "Gebäudereinigung",
  "Immobilienmakler",
  "Fahrschule",
  "Restaurant",
] as const;

export const COUNT_OPTIONS = [20, 50, 100, 200] as const;
export const PAGE_SIZE = 6;
export const OTHER_NICHE = "__other";

const isHttp = (url: string | null): url is string => !!url && /^https?:\/\//i.test(url);

export function mainMenuKeyboard(lang: Language = "ru"): InlineKeyboard {
  return new InlineKeyboard()
    .text(t(lang, "find"), "m:find")
    .row()
    .text(t(lang, "dashboard"), "m:dash")
    .text(t(lang, "leads"), "m:leads")
    .row()
    .text(t(lang, "favorites"), "m:favs")
    .text(t(lang, "settings"), "m:set");
}

export function nicheKeyboard(lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  NICHES.forEach((niche, i) => {
    kb.text(nicheLabel(niche, lang), `niche:${niche}`);
    if (i % 2 === 1) kb.row();
  });
  kb.row().text(t(lang, "other"), `niche:${OTHER_NICHE}`);
  return kb;
}

export function countKeyboard(): InlineKeyboard {
  const kb = new InlineKeyboard();
  COUNT_OPTIONS.forEach((count) => kb.text(String(count), `cnt:${count}`));
  return kb;
}

export function leadCardKeyboard(v: LeadView, lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard().text(t(lang, "open"), `ld:o:${v.id}`);
  if (isHttp(v.mapsUrl)) kb.url(t(lang, "maps"), v.mapsUrl);
  kb.row();
  if (isHttp(v.websiteUrl)) kb.url(t(lang, "website"), v.websiteUrl);
  kb.text(v.isFavorite ? t(lang, "unfavorite") : t(lang, "favorite"), `ld:fav:${v.id}`).row();
  kb.text(t(lang, "aiMessage"), `ld:msg:${v.id}`);
  return kb;
}

export function leadDetailsKeyboard(v: LeadView, lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  if (isHttp(v.websiteUrl)) kb.url(t(lang, "website"), v.websiteUrl);
  if (isHttp(v.mapsUrl)) kb.url(t(lang, "maps"), v.mapsUrl);
  if (isHttp(v.websiteUrl) || isHttp(v.mapsUrl)) kb.row();
  if (isHttp(v.instagramUrl)) kb.url(t(lang, "instagram"), v.instagramUrl).row();
  kb.text(v.isFavorite ? t(lang, "unfavorite") : t(lang, "favorite"), `ld:fav:${v.id}`)
    .text(t(lang, "aiMessage"), `ld:msg:${v.id}`)
    .row();
  const hasBrief = lang === "de" ? !!v.salesBriefDe : !!v.salesBrief;
  if (!hasBrief) kb.text(t(lang, "salesBrief"), `ld:brief:${v.id}`).row();
  kb.text(`📌 ${t(lang, "crm")}: ${crmLabel(v.crmStatus, lang)}`, `ld:st:${v.id}`).row();
  kb.text(t(lang, "note"), `ld:note:${v.id}`).text(t(lang, "price"), `ld:price:${v.id}`).row();
  kb.text(t(lang, "back"), "ls:p:0");
  return kb;
}

export function statusKeyboard(leadId: string, current: string, lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  CRM_STATUSES.forEach((status, i) => {
    kb.text(status === current ? `• ${crmLabel(status, lang)}` : crmLabel(status, lang), `ld:ss:${leadId}:${status}`);
    if (i % 2 === 1) kb.row();
  });
  kb.row().text(t(lang, "back"), `ld:d:${leadId}`);
  return kb;
}

export function messageKeyboard(leadId: string, lang: Language = "ru"): InlineKeyboard {
  return new InlineKeyboard().text(t(lang, "regenerate"), `ld:msg:${leadId}:new`).text(t(lang, "backToLead"), `ld:d:${leadId}`);
}

export function listKeyboard(views: LeadView[], page: number, totalPages: number, lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  for (const v of views) {
    const label = `${v.emoji} ${v.score} · ${v.name}${v.city ? ` (${v.city})` : ""}`;
    kb.text(label.length > 48 ? `${label.slice(0, 47)}…` : label, `ld:d:${v.id}`).row();
  }
  if (totalPages > 1) {
    if (page > 0) kb.text("⬅️", `ls:p:${page - 1}`);
    kb.text(`${page + 1}/${totalPages}`, `ls:p:${page}`);
    if (page < totalPages - 1) kb.text("➡️", `ls:p:${page + 1}`);
    kb.row();
  }
  kb.text(t(lang, "filters"), "ls:f").text(t(lang, "sort"), "ls:s").row();
  kb.text(t(lang, "menu"), "m:home");
  return kb;
}

export function filtersKeyboard(active: string[], lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  FILTERS.forEach((f, i) => {
    kb.text(`${active.includes(f.code) ? "✅ " : ""}${filterLabel(f.code, lang)}`, `ls:ft:${f.code}`);
    if (i % 2 === 1) kb.row();
  });
  kb.row().text(t(lang, "clear"), "ls:fc").text(t(lang, "show"), "ls:p:0");
  return kb;
}

export function sortKeyboard(current: string, lang: Language = "ru"): InlineKeyboard {
  const kb = new InlineKeyboard();
  SORTS.forEach((s) => kb.text(`${s.code === current ? "• " : ""}${sortLabel(s.code, lang)}`, `ls:ss:${s.code}`));
  kb.row().text(t(lang, "back"), "ls:p:0");
  return kb;
}

export function jobDoneKeyboard(lang: Language = "ru"): InlineKeyboard {
  return new InlineKeyboard().text(t(lang, "leads"), "m:leads").text(t(lang, "menu"), "m:home");
}

export function settingsKeyboard(lang: Language = "ru"): InlineKeyboard {
  return new InlineKeyboard().text(t(lang, "setSignature"), "set:name").row().text(t(lang, "language"), "set:language").row().text(t(lang, "menu"), "m:home");
}

export function languageKeyboard(): InlineKeyboard {
  return new InlineKeyboard().text("🇷🇺 Русский", "set:lang:ru").text("🇩🇪 Deutsch", "set:lang:de").row().text("⬅️ Назад", "m:set");
}
